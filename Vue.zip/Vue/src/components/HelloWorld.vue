<template>
  <div class="Navbar">
    <b-navbar toggleable="lg" type="dark" variant="info">
    <b-navbar-brand href="#">Home</b-navbar-brand>

    <b-navbar-toggle target="nav-collapse"></b-navbar-toggle>

    <b-collapse id="nav-collapse" is-nav>
      <b-navbar-nav>
        <b-nav-item href="#" @click=totoro>Aggrid</b-nav-item>
      </b-navbar-nav>
    </b-collapse>
  </b-navbar>
  </div>


  
                                                                            


</template>




<script>
import { BNavbar } from 'bootstrap-vue'

import Vue from 'vue'
Vue.component('b-navbar', BNavbar)
import axios from 'axios'
import {ref} from 'vue'




export default {
  name: 'HelloWorld',
  props: {
    msg: String
  },

  methods:{
    totoro(){
      const movie = ref('')

      const loadID = async() =>{
        const response = await axios.get('http://localhost:8080/ghiblis')
        movie.value = response.data[0].director

        console.log(response.data[2].title)
      }
      loadID()
    }

  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>

<!-- Calling in the API and retrieving details -->
<!-- totoro(){
      const movie = ref('')

      const loadID = async() =>{
        const response = await axios.get('http://localhost:8080/ghiblis')
        movie.value = response.data[0].director

        console.log(response.data[2].title)
      }
      loadID()
    }

  }
} -->