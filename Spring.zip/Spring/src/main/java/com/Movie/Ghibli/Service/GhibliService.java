package com.Movie.Ghibli.Service;
// package com.Movie.Ghibli;

// import java.util.List;
// // import java.util.Optional;

// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.stereotype.Service;

// @Service
// public class GhibliService {

//     @Autowired
//     private static GhibliRepository ghibliRepository;

//     public static List<Ghibli> getPost(int i) {
// 		  return ghibliRepository.findById(i);
// 	  }
    
// }


