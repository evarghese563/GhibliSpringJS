package com.Movie.Ghibli;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GhibliApplicationTests {

	@Test
	void contextLoads() {
	}

}
